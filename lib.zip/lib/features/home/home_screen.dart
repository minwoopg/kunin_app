import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/app_router.dart';
import '../../core/providers/cart_provider.dart';
import '../../core/providers/product_provider.dart';
import '../../core/providers/recently_viewed_provider.dart';
import '../../core/providers/wishlist_provider.dart';
import '../../data/models/product_model.dart';
import '../../shared/theme/app_theme.dart';
import '../../shared/widgets/product_card.dart';
import '../../shared/widgets/state_views.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cartCount = ref.watch(cartCountProvider);

    // 신상품 태그가 붙은 상품만 조회 (Repository 경유, 비동기)
    const newArrivalsQuery = ProductQuery(tag: ProductTag.newItem);
    final newProductsAsync = ref.watch(productsProvider(newArrivalsQuery));

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: const Text(
          'KIP 2026',
          style: TextStyle(
            fontFamily: 'Pretendard',
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: AppColors.textMain,
            letterSpacing: 2,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.textMain),
            onPressed: () => context.push(AppRoutes.search),
          ),
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_bag_outlined, color: AppColors.textMain),
                onPressed: () => context.go(AppRoutes.cart),
              ),
              if (cartCount > 0)
                Positioned(
                  top: 8, right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                    decoration: const BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                    child: Text('$cartCount',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 9, color: AppColors.white, fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () async {
          // 나중에 실제 API 연동 시 여기가 진짜 "새로고침"이 됩니다.
          ref.invalidate(productsProvider(newArrivalsQuery));
          await ref.read(productsProvider(newArrivalsQuery).future);
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 메인 배너
              _MainBanner(onTap: () => context.go(AppRoutes.productList)),
              const SizedBox(height: 28),

              // 카테고리 바로가기
              _CategorySection(
                onSelect: (cat) => context.go(AppRoutes.productListWithCategory(cat)),
              ),
              const SizedBox(height: 28),

              // 신상품 섹션
              _SectionHeader(
                title: 'NEW ARRIVALS',
                onTap: () => context.go(AppRoutes.productList),
              ),
              const SizedBox(height: 12),
              newProductsAsync.when(
                data: (products) => _ProductGrid(products: products.take(4).toList()),
                loading: () => const SizedBox(
                  height: 240,
                  child: LoadingStateView(),
                ),
                // 신상품 섹션 하나가 실패했다고 홈 전체를 에러 화면으로 막지 않고 조용히 숨깁니다.
                error: (error, stack) => const SizedBox.shrink(),
              ),

              // 최근 본 상품 섹션 (기록이 있을 때만 표시)
              const _RecentlyViewedSection(),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

// ── 메인 배너 ──────────────────────────────
class _MainBanner extends StatelessWidget {
  final VoidCallback onTap;
  const _MainBanner({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        height: 200,
        decoration: BoxDecoration(
          color: AppColors.premiumPoint,
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        child: Stack(
          children: [
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(AppRadius.xl),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppColors.premiumPoint,
                      AppColors.primary.withOpacity(0.6),
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('BEAUTY',
                    style: TextStyle(
                      fontFamily: 'Pretendard', fontSize: 28,
                      fontWeight: FontWeight.w800, color: AppColors.white,
                      letterSpacing: 2, height: 1.1,
                    ),
                  ),
                  const Text('BEYOND TIME',
                    style: TextStyle(
                      fontFamily: 'Pretendard', fontSize: 28,
                      fontWeight: FontWeight.w800, color: AppColors.white,
                      letterSpacing: 2, height: 1.1,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                    ),
                    child: const Text('SHOP NOW',
                      style: TextStyle(
                        fontFamily: 'Pretendard', fontSize: 12,
                        fontWeight: FontWeight.w600, color: AppColors.primary,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── 카테고리 섹션 ──────────────────────────
class _CategorySection extends StatelessWidget {
  final ValueChanged<ProductCategory> onSelect;
  const _CategorySection({required this.onSelect});

  static const _icons = {
    ProductCategory.medicalDevice: Icons.medical_services_outlined,
    ProductCategory.diagnostic:    Icons.biotech_outlined,
    ProductCategory.beautyCare:    Icons.spa_outlined,
    ProductCategory.medicine:      Icons.medication_outlined,
    ProductCategory.health:        Icons.health_and_safety_outlined,
  };

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 88,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: ProductCategory.values.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (context, i) {
          final cat = ProductCategory.values[i];
          return GestureDetector(
            onTap: () => onSelect(cat),
            child: Column(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: AppColors.cardBackground,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border, width: 0.8),
                  ),
                  child: Icon(_icons[cat], color: AppColors.primary, size: 24),
                ),
                const SizedBox(height: 6),
                Text(cat.label,
                  style: const TextStyle(
                    fontFamily: 'Pretendard', fontSize: 11,
                    color: AppColors.textSub,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ── 섹션 헤더 ──────────────────────────────
class _SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  const _SectionHeader({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(title,
            style: const TextStyle(
              fontFamily: 'Pretendard', fontSize: 14,
              fontWeight: FontWeight.w700, color: AppColors.textMain,
              letterSpacing: 1.5,
            ),
          ),
          GestureDetector(
            onTap: onTap,
            child: const Text('더보기 >',
              style: TextStyle(fontSize: 12, color: AppColors.textSub),
            ),
          ),
        ],
      ),
    );
  }
}

// ── 상품 그리드 ─────────────────────────────
class _ProductGrid extends ConsumerWidget {
  final List<Product> products;
  const _ProductGrid({required this.products});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favoriteIds = ref.watch(wishlistProvider);

    return GridView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 0.72,
      ),
      itemCount: products.length,
      itemBuilder: (context, i) {
        final product = products[i];
        return ProductCard(
          product: product,
          isFavorite: favoriteIds.contains(product.id),
          onFavoriteToggle: () => ref.read(wishlistProvider.notifier).toggle(product.id),
          onTap: () => context.push('/products/${product.id}'),
        );
      },
    );
  }
}

// ── 최근 본 상품 (가로 스크롤 미리보기) ────
class _RecentlyViewedSection extends ConsumerWidget {
  const _RecentlyViewedSection();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final products = ref.watch(recentlyViewedProductsProvider);
    if (products.isEmpty) return const SizedBox.shrink();

    final preview = products.take(8).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 28),
        _SectionHeader(
          title: '최근 본 상품',
          onTap: () => context.push(AppRoutes.recentlyViewed),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 205,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 20),
            itemCount: preview.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              final product = preview[i];
              return SizedBox(
                width: 140,
                child: ProductCard(
                  product: product,
                  onTap: () => context.push('/products/${product.id}'),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
